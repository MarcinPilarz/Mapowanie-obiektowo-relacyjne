package com.backend.visitsdoctor.models;

public enum VisitStatus {
    SCHEDULED, 
    COMPLETED, 
    CANCELED,
    PAID
}
