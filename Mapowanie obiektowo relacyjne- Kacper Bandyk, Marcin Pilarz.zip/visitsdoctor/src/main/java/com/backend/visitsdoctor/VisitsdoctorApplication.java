package com.backend.visitsdoctor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VisitsdoctorApplication {

	public static void main(String[] args) {
		SpringApplication.run(VisitsdoctorApplication.class, args);
	}

}
